package com.example.prachi.project;


public interface OnSeatSelected {

    void onSeatSelected(int count);
}

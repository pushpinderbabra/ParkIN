package com.example.prachi.project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Booking_History extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking__history);
    }
}
